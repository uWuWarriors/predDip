package com.example.teststudent

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class Question(
    val id_TestTask: String,
    val Question: String,
    val option1: String,
    val option2: String,
    val option3: String,
    val option4: String,
    val is_correct: String,
    val id_test: String
)

class TestCreatorActivity : AppCompatActivity() {
    var UUIDTestTask: String = ""
    var UUIDTest: String = ""
    var NameTest: String = ""
    companion object {
        val ConnectBDClass = ConnectBD()
    }
    var supabase = ConnectBDClass.supabase
    private lateinit var questionsContainer: LinearLayout
    private lateinit var addQuestionButton: Button
    private lateinit var saveTestButton: Button
    private lateinit var editNameTest: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test_creator)
        questionsContainer = findViewById(R.id.questionsContainer)
        addQuestionButton = findViewById(R.id.addQuestionButton)
        saveTestButton = findViewById(R.id.saveTestButton)
        editNameTest = findViewById(R.id.editNameTest)
        addQuestionButton.setOnClickListener { addQuestion() }
        saveTestButton.setOnClickListener { saveTest() }
        UUIDTestTask = UUID.randomUUID().toString()
        UUIDTest = UUID.randomUUID().toString()
    }

    private fun addQuestion() {
        val questionView = layoutInflater.inflate(R.layout.question_view, questionsContainer, false)

        // Get references to UI elements
        val questionEditText = questionView.findViewById<EditText>(R.id.questionText)
        val answer1EditText = questionView.findViewById<EditText>(R.id.answer1)
        val answer2EditText = questionView.findViewById<EditText>(R.id.answer2)
        val answer3EditText = questionView.findViewById<EditText>(R.id.answer3)
        val answer4EditText = questionView.findViewById<EditText>(R.id.answer4)
        val correctAnswerEditText = questionView.findViewById<EditText>(R.id.CorrectAnswerEdit)

        // Set initial values
        questionEditText.setText("")
        answer1EditText.setText("")
        answer2EditText.setText("")
        answer3EditText.setText("")
        answer4EditText.setText("")
        correctAnswerEditText.setText("")

        // Add question to container
        questionsContainer.addView(questionView)
    }

    private fun saveTest() {
        val questions = mutableListOf<Question>()
        for (i in 0 until questionsContainer.childCount) {
            val questionView = questionsContainer.getChildAt(i)
            val question = getQuestionFromView(questionView)
            questions.add(question)
            uploadQuestionToSupabase(question)
        }

        // Here you would typically save the test to a database or send it to a server
        // For now, we'll just show a toast message
        Toast.makeText(this, "Test saved", Toast.LENGTH_SHORT).show()
    }

    private fun getQuestionFromView(questionView: View): Question {
        val questionText = questionView.findViewById<EditText>(R.id.questionText).text.toString()
        val answer1 = questionView.findViewById<EditText>(R.id.answer1).text.toString()
        val answer2 = questionView.findViewById<EditText>(R.id.answer2).text.toString()
        val answer3 = questionView.findViewById<EditText>(R.id.answer3).text.toString()
        val answer4 = questionView.findViewById<EditText>(R.id.answer4).text.toString()
        val correctAnswer = questionView.findViewById<EditText>(R.id.CorrectAnswerEdit).text.toString()

        return Question(
            id_TestTask = UUIDTestTask,
            Question = questionText,
            option1 = answer1,
            option2 = answer2,
            option3 = answer3,
            option4 = answer4,
            is_correct = correctAnswer,
            id_test = UUIDTest
        )
    }

    private fun uploadQuestionToSupabase(question: Question) {
        NameTest = editNameTest.text.toString() // Исправленное использование editNameTest.text.toString()
        lifecycleScope.launch {
            //получить и добавить
            val user = supabase.auth.retrieveUserForCurrentSession(updateSession = true)
            val AddTestData = AddTest(id_test = UUIDTest, name = NameTest, user_id = user.id)
            val addTest = supabase.from("Test").insert(AddTestData)
            val response = supabase.from("TestTask").insert(question)

        }
    }
}

@Serializable
data class AddTest(
    val id_test: String,
    val name: String,
    val user_id: String
)