package com.example.teststudent

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest

public class ConnectBD {
    val supabase = createSupabaseClient(
        supabaseUrl = "https://ziqygzgdllicljujwdql.supabase.co",
        supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InppcXlnemdkbGxpY2xqdWp3ZHFsIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTcxMjA1OTE2OSwiZXhwIjoyMDI3NjM1MTY5fQ.KajLrLyS-g-FlfarB8IAI_17Q0h6Oicz-_nKZId-htg"
    ) {
        install(Auth)
        install(Postgrest){
        }
    }
}