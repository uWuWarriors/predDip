package com.example.teststudent

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

class MainActivity : AppCompatActivity() {
    companion object {
        val ConnectBDClass = ConnectBD()
    }
    var mail: String? = null
    var pass: String? = null
    var userID: String? = null
    var userRole: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val edit_email = findViewById(R.id.email_edit) as EditText
        val edit_pass = findViewById(R.id.password_edit) as EditText
        val btnLog = findViewById(R.id.btn_log_1) as Button
        val btnReg = findViewById(R.id.btn_reg_1) as Button
        btnLog.isEnabled=false
        val supabase = ConnectBDClass.supabase
        edit_email.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    edit_email.error = null
                    btnLog.isEnabled=true
                }else{
                    edit_email.error = "Введите E-mail."
                    btnLog.isEnabled=false
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                mail = edit_email.text.toString()
            }
        })
        edit_pass.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>6){
                        edit_pass.error = null
                        btnLog.isEnabled=true
                    }else{
                        edit_pass.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                pass = edit_pass.text.toString()
            }

        })
        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                //Запрос авторизации с переходом на окно + запрос данных с таблицы auth.user на предмет роли
                lifecycleScope.launch {
                    supabase.auth.signInWith(Email) {
                        email = mail.toString()
                        password = pass.toString()
                    }
                }
                lifecycleScope.launch {
                    val user = supabase.auth.retrieveUserForCurrentSession(updateSession = true)
                    Log.e("!", user.id)
                    var usersRole = supabase.from("userRole").select(){
                        filter {
                            eq("id", user.id)
                        }
                    }.decodeList<userId>()//.decodeSingle<userId>()

                    //userID = user.id
                   // userRole = usersRole.toString()
                    userRole = usersRole[0].role;
                    Log.e("!", "АВТОРИЗАЦИЯ ПРОШЛА")
                    if (userRole == "Student") {
                        val intent = Intent(applicationContext, TestSelectClass::class.java)
                        startActivity(intent)
                    } else if (userRole == "Teacher") {
                        val intent = Intent(applicationContext, SelectActionClass::class.java)
                        startActivity(intent)
                    }
                }

            }

        })
/*        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                if (userRole == "Student") {
                    val intent = Intent(applicationContext, TestSelectClass::class.java)
                    startActivity(intent)
                } else if (userRole == "Teacher") {
                    val intent = Intent(applicationContext, SelectActionClass::class.java)
                    startActivity(intent)
                }
            }
        })*/
        btnReg.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                val intent = Intent(applicationContext, RegClass::class.java)
                startActivity(intent)
            }
        })
    }
}


fun CharSequence?.isValidEmail():Boolean{
    return !isNullOrEmpty() && Patterns
        .EMAIL_ADDRESS.matcher(this).matches()
}
@Serializable
data class userId(var id: String, var role:String)