package com.example.teststudent

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button

import androidx.appcompat.app.AppCompatActivity


class SelectActionClass : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_teacher_select_actions)
        val btn_preparation_test = findViewById(R.id.btn_preparation_test) as Button
        val btn_check_results = findViewById(R.id.btn_check_results) as Button
        btn_check_results.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
               // val intent = Intent(applicationContext, ::class.java)
              //  startActivity(intent)
            }
        })
        btn_preparation_test.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                 val intent = Intent(applicationContext, TestCreatorActivity::class.java)
                 startActivity(intent)
            }
        })
    }
}