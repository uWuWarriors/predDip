package com.example.teststudent

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ItemAdapterTestPassing(var items: List<ItemPassing>) : RecyclerView.Adapter<ItemAdapterTestPassing.MyViewHolder>() {

    class MyViewHolder(view: View): RecyclerView.ViewHolder(view){
        val NameTest: TextView = view.findViewById(R.id.textViewName)
        val radiobtn1 : RadioButton = view.findViewById(R.id.radioButton1)
        val radiobtn2 : RadioButton = view.findViewById(R.id.radioButton2)
        val radiobtn3 : RadioButton = view.findViewById(R.id.radioButton3)
        val radiobtn4 : RadioButton = view.findViewById(R.id.radioButton4)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_question_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return items.count()
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.NameTest.text = items[position].questionText
        holder.radiobtn1.text = items[position].option1
        holder.radiobtn2.text = items[position].option2
        holder.radiobtn3.text = items[position].option3
        holder.radiobtn4.text = items[position].option4
    }
}