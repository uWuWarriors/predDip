package com.example.teststudent

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

class PassingTestClass : AppCompatActivity(){
    companion object {
        val ConnectBDClass = ConnectBD()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test_questions)
        var recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        val supabase = TestSelectClass.ConnectBDClass.supabase
        lifecycleScope.launch {
            val user = supabase.auth.retrieveUserForCurrentSession(updateSession = true)
            // = user.id
            val test = supabase.from("TestTask")
                .select()
                .decodeList<ItemPassing>()
            val adapter = ItemAdapterTestPassing(items = test)
            recyclerView.adapter = adapter
        }
    }
}
@Serializable
data class ItemPassing(var questionText: String = "",
                       var option1: String = "",
                       var option2: String = "",
                       var option3: String = "",
                       var option4: String = "",
                       var is_correct: String = "")
